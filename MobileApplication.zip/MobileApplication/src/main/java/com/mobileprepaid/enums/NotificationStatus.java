package com.mobileprepaid.enums;

public enum NotificationStatus {
    SENT, READ
}
