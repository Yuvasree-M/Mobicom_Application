package com.mobileprepaid.enums;

public enum RefundStatus {
    NONE, INITIATED, COMPLETED
}
