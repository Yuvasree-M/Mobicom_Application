package com.mobileprepaid.enums;

public enum RechargeStatus { PENDING, SUCCESS, FAILED }