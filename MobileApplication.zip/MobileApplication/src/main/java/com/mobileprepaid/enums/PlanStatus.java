package com.mobileprepaid.enums;

public enum PlanStatus {
    ACTIVE,
    INACTIVE
}
