package com.mobileprepaid.enums;

public enum SupportStatus {
    PENDING, RESOLVED
}
