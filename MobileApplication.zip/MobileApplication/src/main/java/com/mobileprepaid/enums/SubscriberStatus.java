package com.mobileprepaid.enums;

public enum SubscriberStatus {
	PENDING, ACTIVE, INACTIVE
}
