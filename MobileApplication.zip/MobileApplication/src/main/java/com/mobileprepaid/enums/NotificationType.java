package com.mobileprepaid.enums;

public enum NotificationType {
    PLAN_EXPIRY, NEW_OFFER, SUPPORT_QUERY, GENERAL
}
